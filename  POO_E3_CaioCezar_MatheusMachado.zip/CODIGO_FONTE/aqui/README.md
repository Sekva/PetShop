# PetShop
Agora é segundo periodo

Projeto para curso de POO

## Biblioteca

Uso da biblioteca GSON. Usada para implementar persistencia de dados 
por meio de arquivos json.

* [GSON](https://github.com/google/gson) - GitHub do projeto GSON

## Autores

* **Matheus Machado Vieira** - [Sekva](https://github.com/sekva)
* **Caio Cezar** - [Caio](https://github.com/caiotuchi)

Veja também a lista de [contribuintes](https://github.com/sekva/PetShop/contributors).

<p align="center">

<a href="LICENSE">
<img alt="License" src="https://img.shields.io/github/license/eivindml/misty.svg">
</a>

<br />
<br />
</p>
