package org.grupin.exceptions;

public class ReferenciaInvalidaException extends Exception {

    public ReferenciaInvalidaException() {
        super("Referencia Invalida");
    }


}
