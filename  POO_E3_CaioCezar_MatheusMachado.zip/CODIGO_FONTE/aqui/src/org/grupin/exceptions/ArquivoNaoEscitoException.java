package org.grupin.exceptions;

public class ArquivoNaoEscitoException extends Exception {

    public ArquivoNaoEscitoException() {
        super("Arquivo não escrito");
    }

}
