package org.grupin.exceptions;

public class AgendamentoInvalidoPorId extends Exception {

    public AgendamentoInvalidoPorId() {
        super("Id de agendamento invalido");
    }


}
